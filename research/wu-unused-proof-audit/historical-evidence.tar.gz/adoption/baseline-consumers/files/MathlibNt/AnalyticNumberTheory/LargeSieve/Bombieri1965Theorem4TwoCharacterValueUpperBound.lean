import MathlibNt.AnalyticNumberTheory.Siegel.Bombieri1965Theorem4TwoCharacterValueUpperBound

/-! Compatibility import for the canonical module in its current library location. -/
