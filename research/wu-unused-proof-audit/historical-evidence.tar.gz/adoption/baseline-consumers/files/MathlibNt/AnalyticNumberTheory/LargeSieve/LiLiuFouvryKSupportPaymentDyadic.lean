import MathlibNt.AnalyticNumberTheory.LargeSieve.LiLiuFouvryKSupportPayment

/-!
# Fixed-residue-scale large supported-factor payment at the C.2 dyadic scale

The actual beta endpoint is `2 * T` when `4 * M * T = x`. No power
separation of the lengths is needed, and the modulus endpoint may reach `x`.
The original sum, zero mode and tail retain the same arbitrary mask, with
frequency cutoff exactly `wUniformCutoff M (x ^ η)`.
-/

noncomputable section

open Classical Finset Filter
open scoped Topology

namespace MathlibNt.AnalyticNumberTheory.LargeSieve.LiLiuPrereqFouvry

/-- Uniform logarithmic payment of every submask of the large canonical
`d₁` part of the actual clean truncated W sum. Every divisor order may be
zero; no SW or nondivisibility assumption on the original beta is required. -/
theorem betaClean_wMaskedTruncated_largeSupport_dyadic_kscale
    (i k j A : ℕ) {η Cscale : ℝ} (hη : 0 < η) (hCscale : 1 ≤ Cscale) :
    ∀ᶠ x : ℝ in atTop, ∀ M T L : ℝ,
      1 ≤ M → 1 ≤ T → 1 ≤ L → 4 * M * T = x → L ≤ x →
      ∀ S N Q : Finset ℕ,
      (∀ m ∈ S, M ≤ (m : ℝ) ∧ (m : ℝ) ≤ 2 * M) →
      (∀ n ∈ N, T ≤ (n : ℝ) ∧ (n : ℝ) ≤ 2 * T) →
      Q ⊆ Ioc 0 ⌊L⌋₊ →
      ∀ α β c : ℕ → ℝ,
      (∀ m ∈ S, |α m| ≤ (fouvryTau i m : ℝ)) →
      (∀ n ∈ N, |β n| ≤ (fouvryTau k n : ℝ)) →
      (∀ q ∈ Q, |c q| ≤ (fouvryTau j q : ℝ)) →
      ∀ a : ℤ, |(a : ℝ)| ≤ Cscale * x → ∀ P : WOriginalTuple → Prop,
      (∀ t ∈ wOriginalTuples N Q a, P t →
        x ^ η < ((wGCDData t.1.1 t.1.2 t.2.1 t.2.2).d₁ : ℝ)) →
      (∑ m ∈ S, α m ^ 2) *
        |wMaskedTruncated M (wUniformCutoff M (x ^ η)) N Q
          (betaClean β a) c a P| ≤ x ^ 2 / Real.log x ^ A := by
  let u : ℕ := (i + 1) ^ 2 - 1
  filter_upwards [
    eventually_wMaskedOriginal_zero_largeSupport_power_saving_kscale
      (by omega : 1 ≤ k + 1) j hη hCscale,
    wMaskedTail_uniformCutoff_alpha_log_payment i k j (A + 1) hη,
    betaPayment_eventually_log_mul_rpow_le 4 (by norm_num) (u + (A + 1))
      (b := -η / 8) (d := 0) (by linarith),
    eventually_ge_atTop (1 : ℝ),
    Real.tendsto_log_atTop.eventually_ge_atTop (2 : ℝ)]
    with x hpower htail hpay hx hlog
  intro M T L hM hT _hL hscale hLx S N Q hS hN hQ
    α β c hα hβ hc a hax P hP
  have hM0 : 0 < M := by linarith
  have hT0 : 0 < T := by linarith
  have hMT : M * (2 * T) ≤ x := by nlinarith
  have hMx : 2 * M ≤ x := by nlinarith
  have hTx : 2 * T ≤ x := by nlinarith
  have hNupper : N ⊆ Ioc 0 ⌊2 * T⌋₊ := by
    intro n hn
    refine mem_Ioc.mpr ⟨?_, Nat.le_floor (hN n hn).2⟩
    have : (0 : ℝ) < n := by have := (hN n hn).1; linarith
    exact_mod_cast this
  have hSx : S ⊆ Ioc 0 ⌊x⌋₊ := by
    intro m hm
    refine mem_Ioc.mpr ⟨?_, Nat.le_floor ((hS m hm).2.trans hMx)⟩
    have : (0 : ℝ) < m := by have := (hS m hm).1; linarith
    exact_mod_cast this
  have hNx : N ⊆ Ioc 0 ⌊x⌋₊ :=
    hNupper.trans (Ioc_subset_Ioc_right (Nat.floor_mono hTx))
  have hQx : Q ⊆ Ioc 0 ⌊x⌋₊ :=
    hQ.trans (Ioc_subset_Ioc_right (Nat.floor_mono hLx))
  have hclean : ∀ n ∈ N, |betaClean β a n| ≤ (fouvryTau k n : ℝ) :=
    fun n hn ↦ (abs_betaClean_le _ _ _).trans (hβ n hn)
  have hclean' : ∀ n ∈ N, |betaClean β a n| ≤ (fouvryTau (k + 1) n : ℝ) :=
    fun n hn ↦ (hclean n hn).trans (by exact_mod_cast fouvryTau_le_succ k n)
  have hα' : ∀ m ∈ S, |α m| ≤ (fouvryTau (i + 1) m : ℝ) :=
    fun m hm ↦ (hα m hm).trans (by exact_mod_cast fouvryTau_le_succ i m)
  have hheadPower := hpower M (2 * T) hM (by linarith) hMT
    N Q hNupper hQx (betaClean β a) c hclean' hc a hax
    (fun _ _ hn ↦ betaClean_nonzero_not_dvd hn) P hP
  have htailPay := htail M hM0 S N Q hSx hNx hQx α (betaClean β a) c
    hα hclean hc a P
  let H := 1 + Real.log x
  have hH : 0 ≤ H := by dsimp [H]; linarith
  have hlog0 : 0 < Real.log x := by linarith
  have hAlpha : (∑ m ∈ S, α m ^ 2) ≤ 2 * M * H ^ u := by
    apply (sum_alpha_sq_dyadic_le (by omega : 1 ≤ i + 1) hM S hS α hα').trans
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    apply pow_le_pow_left₀ (by linarith [Real.log_nonneg (show 1 ≤ 2 * M by linarith)])
    dsimp [H]
    linarith [Real.log_le_log (by positivity : 0 < 2 * M) hMx]
  exact wMaskedTruncated_dyadic_power_payment hM0 hT0 (by linarith) hMT hlog
    (sum_nonneg (fun _ _ ↦ sq_nonneg _)) hAlpha
    (by simpa only [Real.rpow_zero] using hpay)
    (wUniformCutoff M (x ^ η)) N Q (betaClean β a) c a P
    (fun q hq ↦ (mem_Ioc.mp (hQx hq)).1.ne') hheadPower htailPay

end MathlibNt.AnalyticNumberTheory.LargeSieve.LiLiuPrereqFouvry
