

import MathlibNt.AnalyticNumberTheory.Vaughan.VaughanDirectAPNormalizedTypeIIActualDecomposition

/-!
 # Rank-one rectangular primitive L¹ means

This leaf separates the elementary rectangular part of a Type-II first moment
from the genuinely hyperbolic prefix problem.  A rank-one rectangle is paid by
two one-dimensional weighted primitive large sieves and one Cauchy--Schwarz
inequality.  The sole remaining interface says that an actual collected
Vaughan hyperbolic shell is dominated by finitely many such rectangles.

This module is intentionally not imported by a canonical facade.
-/

namespace AnalyticNumberTheory.LargeSieve

open Classical Finset
open scoped BigOperators

noncomputable section

/-- Weighted primitive first moment of a rank-one rectangular character sum.
The conductor set is explicit so the same theorem applies to one production
conductor block. -/
def rankOneRectangularWeightedPrimitiveMean
    (a b : ℤ → ℂ) (Ma Mb : ℤ) (Na Nb : ℕ) (S : Finset ℕ) : ℝ :=
  ∑ q ∈ S, ((q : ℝ) / (q.totient : ℝ)) *
    ∑ χ : PrimitiveCharacter q,
      ‖∑ m ∈ Finset.Icc (Ma + 1) (Ma + Na),
          a m * χ.1 (m : ZMod q)‖ *
        ‖∑ n ∈ Finset.Icc (Mb + 1) (Mb + Nb),
          b n * χ.1 (n : ZMod q)‖

lemma rankOneRectangularWeightedPrimitiveMean_nonneg
    (a b : ℤ → ℂ) (Ma Mb : ℤ) (Na Nb : ℕ) (S : Finset ℕ) :
    0 ≤ rankOneRectangularWeightedPrimitiveMean a b Ma Mb Na Nb S := by
  unfold rankOneRectangularWeightedPrimitiveMean
  positivity

/-- The elementary rectangular theorem.  After flattening the finite dependent
family `(q,χ)`, Cauchy gives two square ledgers; each is exactly one invocation
of the one-dimensional weighted primitive large sieve. -/
theorem rankOneRectangularWeightedPrimitiveMean_sq_le
    (a b : ℤ → ℂ) (Ma Mb : ℤ) (Na Nb Q : ℕ) (hQ : 0 < Q)
    (S : Finset ℕ) (hS : S ⊆ Finset.Icc 1 Q) :
    rankOneRectangularWeightedPrimitiveMean a b Ma Mb Na Nb S ^ 2 ≤
      (largeSieveBound Na (1 / (Q : ℝ) ^ 2) *
        ∑ m ∈ Finset.Icc (Ma + 1) (Ma + Na), ‖a m‖ ^ 2) *
      (largeSieveBound Nb (1 / (Q : ℝ) ^ 2) *
        ∑ n ∈ Finset.Icc (Mb + 1) (Mb + Nb), ‖b n‖ ^ 2) := by
  let w : ℕ → ℝ := fun q => (q : ℝ) / (q.totient : ℝ)
  let A : (q : ℕ) → PrimitiveCharacter q → ℝ := fun q χ =>
    ‖∑ m ∈ Finset.Icc (Ma + 1) (Ma + Na), a m * χ.1 (m : ZMod q)‖
  let B : (q : ℕ) → PrimitiveCharacter q → ℝ := fun q χ =>
    ‖∑ n ∈ Finset.Icc (Mb + 1) (Mb + Nb), b n * χ.1 (n : ZMod q)‖
  let T := S.sigma (fun q => (Finset.univ : Finset (PrimitiveCharacter q)))
  have hflat : rankOneRectangularWeightedPrimitiveMean a b Ma Mb Na Nb S =
      ∑ x ∈ T, (Real.sqrt (w x.1)) * A x.1 x.2 *
        ((Real.sqrt (w x.1)) * B x.1 x.2) := by
    unfold rankOneRectangularWeightedPrimitiveMean
    dsimp [T]
    rw [Finset.sum_sigma]
    apply Finset.sum_congr rfl
    intro q hq
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro χ hχ
    have hw : 0 ≤ w q := by dsimp [w]; positivity
    calc
      ((q : ℝ) / (q.totient : ℝ)) * (A q χ * B q χ) =
          (Real.sqrt (w q) * Real.sqrt (w q)) * (A q χ * B q χ) := by
            rw [Real.mul_self_sqrt hw]
      _ = Real.sqrt (w q) * A q χ * (Real.sqrt (w q) * B q χ) := by ring
  rw [hflat]
  refine (Finset.sum_mul_sq_le_sq_mul_sq T
    (fun x => Real.sqrt (w x.1) * A x.1 x.2)
    (fun x => Real.sqrt (w x.1) * B x.1 x.2)).trans ?_
  have hsquare_flat (F : (q : ℕ) → PrimitiveCharacter q → ℝ) :
      (∑ x ∈ T, (Real.sqrt (w x.1) * F x.1 x.2) ^ 2) =
        ∑ q ∈ S, w q * ∑ χ : PrimitiveCharacter q, F q χ ^ 2 := by
    dsimp [T]
    rw [Finset.sum_sigma]
    apply Finset.sum_congr rfl
    intro q hq
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro χ hχ
    have hw : 0 ≤ w q := by dsimp [w]; positivity
    rw [mul_pow, Real.sq_sqrt hw]
  have hlarge (c : ℤ → ℂ) (M : ℤ) (L : ℕ) :
      (∑ q ∈ S, w q * ∑ χ : PrimitiveCharacter q,
        ‖∑ n ∈ Finset.Icc (M + 1) (M + L), c n * χ.1 (n : ZMod q)‖ ^ 2) ≤
      largeSieveBound L (1 / (Q : ℝ) ^ 2) *
        ∑ n ∈ Finset.Icc (M + 1) (M + L), ‖c n‖ ^ 2 := by
    calc
      _ ≤
          ∑ q ∈ Finset.Icc 1 Q,
            w q * ∑ χ : PrimitiveCharacter q,
              ‖∑ n ∈ Finset.Icc (M + 1) (M + L), c n * χ.1 (n : ZMod q)‖ ^ 2 := by
        apply Finset.sum_le_sum_of_subset_of_nonneg hS
        intro q hq hnot
        exact mul_nonneg (by dsimp [w]; positivity)
          (Finset.sum_nonneg fun χ hχ => sq_nonneg _)
      _ ≤ _ := by
        simpa [w] using weighted_primitive_bombieri_davenport c M L Q hQ
  rw [hsquare_flat A, hsquare_flat B]
  apply mul_le_mul
  · exact hlarge a Ma Na
  · exact hlarge b Mb Nb
  · exact Finset.sum_nonneg fun q hq => mul_nonneg (by dsimp [w]; positivity)
      (Finset.sum_nonneg fun χ hχ => sq_nonneg _)
  · unfold largeSieveBound
    positivity

/-- Unsquared form convenient for finite shell assembly. -/
theorem rankOneRectangularWeightedPrimitiveMean_le
    (a b : ℤ → ℂ) (Ma Mb : ℤ) (Na Nb Q : ℕ) (hQ : 0 < Q)
    (S : Finset ℕ) (hS : S ⊆ Finset.Icc 1 Q) :
    rankOneRectangularWeightedPrimitiveMean a b Ma Mb Na Nb S ≤
      Real.sqrt (largeSieveBound Na (1 / (Q : ℝ) ^ 2) *
        ∑ m ∈ Finset.Icc (Ma + 1) (Ma + Na), ‖a m‖ ^ 2) *
      Real.sqrt (largeSieveBound Nb (1 / (Q : ℝ) ^ 2) *
        ∑ n ∈ Finset.Icc (Mb + 1) (Mb + Nb), ‖b n‖ ^ 2) := by
  have hs := rankOneRectangularWeightedPrimitiveMean_sq_le
    a b Ma Mb Na Nb Q hQ S hS
  have hA : 0 ≤ largeSieveBound Na (1 / (Q : ℝ) ^ 2) *
      ∑ m ∈ Finset.Icc (Ma + 1) (Ma + Na), ‖a m‖ ^ 2 := by
    unfold largeSieveBound
    positivity
  have hB : 0 ≤ largeSieveBound Nb (1 / (Q : ℝ) ^ 2) *
      ∑ n ∈ Finset.Icc (Mb + 1) (Mb + Nb), ‖b n‖ ^ 2 := by
    unfold largeSieveBound
    positivity
  have hright : 0 ≤
      Real.sqrt (largeSieveBound Na (1 / (Q : ℝ) ^ 2) *
        ∑ m ∈ Finset.Icc (Ma + 1) (Ma + Na), ‖a m‖ ^ 2) *
      Real.sqrt (largeSieveBound Nb (1 / (Q : ℝ) ^ 2) *
        ∑ n ∈ Finset.Icc (Mb + 1) (Mb + Nb), ‖b n‖ ^ 2) :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)
  apply (sq_le_sq₀ (rankOneRectangularWeightedPrimitiveMean_nonneg
    a b Ma Mb Na Nb S) hright).mp
  rw [mul_pow, Real.sq_sqrt hA, Real.sq_sqrt hB]
  exact hs


end

end AnalyticNumberTheory.LargeSieve
