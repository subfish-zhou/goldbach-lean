import MathlibNt.AnalyticNumberTheory.LargeSieve.DampedArctanHyperbolicPrimitiveL1

namespace AnalyticNumberTheory.LargeSieve

open Finset

/-- The number of primitive characters modulo a positive `q` is at most Euler's
 totient.  This is the cardinality bound coming directly from the subtype definition. -/
private theorem primitiveCharacter_card_le_totient_mass (q : ℕ) (hq : 0 < q) :
    Fintype.card (PrimitiveCharacter q) ≤ q.totient := by
  exact primitiveCharacter_card_le_totient_basic q hq

private theorem sum_Icc_one_cast (Q : ℕ) :
    (∑ q ∈ Icc 1 Q, (q : ℝ)) = (Q : ℝ) * ((Q : ℝ) + 1) / 2 := by
  induction Q with
  | zero => simp
  | succ Q ih =>
      rw [sum_Icc_succ_top (by omega : 1 ≤ Q + 1), ih]
      push_cast
      ring

/-- A primitive family supported on conductors in `[1,Q]` has weighted mass at
most the triangular number `Q(Q+1)/2`. -/
theorem weightedPrimitiveFamilyMass_le_triangular
    (Q : ℕ) (S : Finset ℕ) (hS : S ⊆ Icc 1 Q) :
    weightedPrimitiveFamilyMass S ≤ (Q : ℝ) * ((Q : ℝ) + 1) / 2 := by
  have hterm : ∀ q ∈ S,
      ((q : ℝ) / (q.totient : ℝ)) * Fintype.card (PrimitiveCharacter q) ≤ (q : ℝ) := by
    intro q hq
    have hq1 : 1 ≤ q := (mem_Icc.mp (hS hq)).1
    have hq0 : 0 < q := by omega
    have htot : 0 < (q.totient : ℝ) := by
      exact_mod_cast Nat.totient_pos.mpr hq0
    have hcard : (Fintype.card (PrimitiveCharacter q) : ℝ) ≤ (q.totient : ℝ) := by
      exact_mod_cast primitiveCharacter_card_le_totient_mass q hq0
    calc
      _ ≤ ((q : ℝ) / (q.totient : ℝ)) * (q.totient : ℝ) :=
        mul_le_mul_of_nonneg_left hcard (by positivity)
      _ = (q : ℝ) := div_mul_cancel₀ _ htot.ne'
  unfold weightedPrimitiveFamilyMass
  calc
    (∑ q ∈ S, ((q : ℝ) / (q.totient : ℝ)) * Fintype.card (PrimitiveCharacter q)) ≤
        ∑ q ∈ S, (q : ℝ) := by
          exact sum_le_sum fun q hq => hterm q hq
    _ ≤ ∑ q ∈ Icc 1 Q, (q : ℝ) := by
      exact sum_le_sum_of_subset_of_nonneg hS (fun _ _ _ => Nat.cast_nonneg _)
    _ = (Q : ℝ) * ((Q : ℝ) + 1) / 2 := sum_Icc_one_cast Q


end AnalyticNumberTheory.LargeSieve
