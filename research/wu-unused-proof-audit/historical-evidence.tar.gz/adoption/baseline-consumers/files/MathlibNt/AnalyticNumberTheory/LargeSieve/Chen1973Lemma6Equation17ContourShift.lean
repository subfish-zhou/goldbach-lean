import MathlibNt.AnalyticNumberTheory.Chen1973.Chen1973Lemma6Equation17ContourShift

/-! Compatibility import for the canonical module in its current library location. -/
