-- UNCOMPILED scratch template. Requires a future root-scheduled Lean check.
-- Reuses ConstantInfo kind classification and binder/mdata traversal from
-- research/chen-audit/TypeCensus.lean; emits full trees, not Lean hash values.
import Lean
import AnalyticNumberTheory.PrimeDistribution.PrimeNumberTheorem
import AnalyticNumberTheory.Sieve.SelbergUpperBound
import Hf4QuadAggregate
import Hf4QuadCompactKernel
import Hf4QuadCompactKernelCore
import Hf4QuadExactOperations
import Hf4QuadIntegral
import Hf4QuadKernel
import Hf4QuadKernelData
import Hf4QuadModel
import Hf4QuadModelBasic
import Hf4QuadModelRadical
import Hf4QuadRatCore
import Hf4QuadRationalModel
import Hf4QuadRationalModelCore
import Hf4RadicalBounds
import Hf4TargetConstants
import MathlibNt.AnalyticNumberTheory.LargeSieve.BombieriDavenport
import MathlibNt.SieveTheory.Distribution.LiuPan.LiuPanAggregatePsiCharacters
import MathlibNt.SieveTheory.Distribution.LiuPan.LiuPanAggregatePsiDyadic
import MathlibNt.SieveTheory.Distribution.LiuPan.LiuPanCombinedAbel
import MathlibNt.SieveTheory.Distribution.LiuPan.LiuPanCombinedInverseLog
import MathlibNt.SieveTheory.Distribution.LiuPan.LiuPanPrimePowerCharacters
import MathlibNt.SieveTheory.Distribution.LiuPan.LiuPanPrimePowerLargeSieve
import MathlibNt.SieveTheory.Distribution.LiuPan.LiuPanPrimitivePerron
import MathlibNt.SieveTheory.JurkatRichert1965ChenGammaOneQOne
import MathlibNt.SieveTheory.LiLiuGoldbachB10LogGridLimit
import MathlibNt.SieveTheory.LiLiuPrereqBuchstabPNT
import MathlibNt.SieveTheory.LinearSieve.Suzuki.SuzukiSection13PairingZero
import MathlibNt.SieveTheory.Liu.PrimePairs.LiuLogCoordinates
import MathlibNt.SieveTheory.Liu.PrimePairs.LiuPrimePairLogGridLimit
import MathlibNt.SieveTheory.Selberg.Liu.LiuSelbergOptimalWeights
import MathlibNt.SieveTheory.Selberg.TruncatedOptimalWeights
import PrimeNumberTheoremAnd.MediumPNTQualitativeBridge
import PrimeNumberTheoremAnd.PNTEnvironmentCompat
import SigmaRationalOuterActual
import SigmaRationalOuterData
import TerminalEPrimitive
import TerminalERadical
import Hf4ConstructiveTablePublic

open Lean
namespace PublicInterfaceAudit

private def node (tag : String) (args : Array Json := #[]) : Json :=
  .arr (#[toJson tag] ++ args)

private def nameTree : Name → Json
  | .anonymous => node "anonymous"
  | .str p s => node "str" #[nameTree p, toJson s]
  | .num p n => node "num" #[nameTree p, toJson n]

private def paramIndex (n : Name) : List Name → Option Nat
  | [] => none
  | p :: ps => if n == p then some 0 else (paramIndex n ps).map (· + 1)

private partial def levelTree (ps : List Name) : Level → Except String Json
  | .zero => return node "zero"
  | .succ u => return node "succ" #[← levelTree ps u]
  | .max u v => return node "max" #[← levelTree ps u, ← levelTree ps v]
  | .imax u v => return node "imax" #[← levelTree ps u, ← levelTree ps v]
  | .param p => match paramIndex p ps with
    | some i => return node "param" #[toJson i]
    | none => throw s!"Undeclared universe parameter: {p}"
  | .mvar _ => throw "Universe metavariable in public declaration"

private def binderTree : BinderInfo → Json
  | .default => toJson "default"
  | .implicit => toJson "implicit"
  | .strictImplicit => toJson "strictImplicit"
  | .instImplicit => toJson "instImplicit"

private partial def exprTree (ps : List Name) : Expr → Except String Json
  | .bvar i => return node "bvar" #[toJson i]
  | .fvar _ => throw "Free variable in public declaration"
  | .mvar _ => throw "Expression metavariable in public declaration"
  | .sort u => return node "sort" #[← levelTree ps u]
  | .const n us => do
    let levels ← us.mapM (levelTree ps)
    return node "const" #[nameTree n, .arr levels.toArray]
  | .app f x => return node "app" #[← exprTree ps f, ← exprTree ps x]
  | .lam _ t b bi => return node "lam" #[binderTree bi, ← exprTree ps t, ← exprTree ps b]
  | .forallE _ t b bi => return node "forall" #[binderTree bi, ← exprTree ps t, ← exprTree ps b]
  | .letE _ t v b nondep => return node "let" #[toJson nondep, ← exprTree ps t, ← exprTree ps v, ← exprTree ps b]
  | .lit (.natVal n) => return node "nat" #[toJson n]
  | .lit (.strVal s) => return node "string" #[toJson s]
  | .mdata _ e => exprTree ps e
  | .proj n i e => return node "proj" #[nameTree n, toJson i, ← exprTree ps e]

private def kind : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition"
  | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

private def declaration (ci : ConstantInfo) (includeDefinitions : Bool) : Except String Json := do
  let ty ← exprTree ci.levelParams ci.type
  let value ←
    if includeDefinitions then
      match ci with
      | .defnInfo d => exprTree ci.levelParams d.value
      | _ => throw s!"Requested definition value for non-definition: {ci.name}"
    else pure Json.null
  return Json.mkObj [
    ("name", toJson ci.name.toString), ("kind", toJson (kind ci)),
    ("levelParamCount", toJson ci.levelParams.length),
    ("type", ty), ("definitionValue", value)]

run_cmd do
  let env ← Lean.getEnv
  let requested : List Name := [(Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "JurkatRichert1965ChenGammaOneQOne") "sieveProduct_eq_one_sub_sum"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "JurkatRichert1965ChenGammaOneQOne") "siftedCount_eq_siftedCount_sub_interval"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "JurkatRichert1965ChenGammaOneQOne") "conditionedSiftedCountOn_siftingPrimes_eq"), (Name.str (Name.str (Name.str Name.anonymous "AnalyticNumberTheory") "Sieve") "v3_moebius_abs_le_one"), (Name.str (Name.str (Name.str Name.anonymous "AnalyticNumberTheory") "Sieve") "vaughanThird_zero"), (Name.str (Name.str (Name.str Name.anonymous "AnalyticNumberTheory") "Sieve") "v3_vonMangoldt_nonneg"), (Name.str (Name.str (Name.str Name.anonymous "AnalyticNumberTheory") "Sieve") "vaughanThird_abs_le"), (Name.str (Name.str (Name.str Name.anonymous "AnalyticNumberTheory") "Sieve") "v3_harmonic_Icc_le"), (Name.str (Name.str (Name.str Name.anonymous "AnalyticNumberTheory") "Sieve") "v3_card_multiples_Icc"), (Name.str (Name.str (Name.str Name.anonymous "AnalyticNumberTheory") "Sieve") "v3_lcm_inv_sum_le"), (Name.str (Name.str (Name.str Name.anonymous "AnalyticNumberTheory") "Sieve") "v3_divisorCountSq_sum_le"), (Name.str (Name.str (Name.str Name.anonymous "AnalyticNumberTheory") "Sieve") "panTypeIICharSqSum_le_additiveSieve"), (Name.str (Name.str (Name.str Name.anonymous "AnalyticNumberTheory") "Sieve") "panTypeIICharSqrtMeanMaxY_le_sum"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "moebius_real_isLowerMoebius"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "abs_moebius_real_le_one"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "mainSum_moebius_eq_correctedChenSieveProduct"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenErrSum_moebius_le_errSum_one"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenCandidates_card_ge_X_mul_sieveProduct_sub_errSum"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenNu_inv_prime"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenNu_inv_prime_localFactor"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenSelbergSum_mul_singularSeriesTruncated"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "primeProduct_pos"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenSelbergSum_eq_sieveProduct_inv"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenSieveProduct_eq_singularSeries_mul_primeProduct"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenMainTerm_lower_of_estimates"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "CorrectedChenMainTermLower_of_uniform_estimates"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenZ_sub_one_le_N"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenZ_sub_one_ge_two_of_large"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "correctedChenZ_log_le_logN"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "CorrectedChenMainTermLower_of_singularSeries_bound"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "CorrectedChenMainTermLower_of_singularSeries_lower"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "singularSeriesTruncated_ge_half"), (Name.str (Name.str (Name.str (Name.str Name.anonymous "MathlibNt") "SieveTheory") "SwitchingPrinciple") "singularSeriesTruncatedLowerBound_ge_half")]
  let includeDefinitions := false
  let mut records : Array Json := #[]
  for n in requested do
    let some ci := env.find? n | throwError "Missing public declaration: {n}"
    match declaration ci includeDefinitions with
    | .error message => throwError "{message}"
    | .ok row => records := records.push row
  let payload := Json.mkObj [
    ("schema", toJson "wu-public-interface-v1"),
    ("normalization", toJson "erase-mdata-binder-names; levelParams-positional-alpha-v1"),
    ("requested_names", toJson (requested.map Name.toString)),
    ("include_definitions", toJson includeDefinitions),
    ("declarations", Json.arr records)]
  Lean.Elab.Command.liftIO <| IO.FS.writeFile "/tmp/wu-shared-proof-batch-v1/validation-inputs-02/after-changed-types.json" payload.compress

end PublicInterfaceAudit
