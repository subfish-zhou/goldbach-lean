import W08KernelMatrix

noncomputable section
namespace WuTarget.W08
open Wu2008DoubleSieve ActualNineFeedback NodeExtension FirstFeedbackIntegrals
open scoped BigOperators

theorem elementaryMatrix_le_paidMatrix (i k : Fin 9) :
    Wu04Bypass.elementaryMatrix i k ≤ paidMatrix i k := by
  unfold Wu04Bypass.elementaryMatrix paidMatrix
  split_ifs
  · exact div_le_div_of_nonneg_right (le_max_left _ _) (by norm_num)
  · exact le_max_left _ _

theorem elementaryCell_nonneg {S a b : ℝ} (hS : 3 ≤ S)
    (ha : S - 2 ≤ a) (hab : a ≤ b) : 0 ≤ Wu04Bypass.cell S a b := by
  have hb : 0 < b := by linarith
  unfold Wu04Bypass.cell
  apply div_nonneg
  · exact mul_nonneg (sub_nonneg.mpr hab) (by linarith)
  · positivity

theorem elementaryNodeCell_nonneg {S : ℝ} (hS : 3 ≤ S)
    (hcell : S - 2 ≤ upperNode 0) (k : Fin 9) :
    0 ≤ Wu04Bypass.cell S (cellLeft (S - 2) k) (upperNode k) := by
  have hb := cell_bounds (by linarith : 1 ≤ S - 2) hcell k
  exact elementaryCell_nonneg hS hb.1 hb.2.1

theorem elementaryMatrix_nonneg (i k : Fin 9) :
    0 ≤ Wu04Bypass.elementaryMatrix i k := by
  unfold Wu04Bypass.elementaryMatrix
  split_ifs with h
  · exact div_nonneg
      (elementaryNodeCell_nonneg (coupledRow_geometry ⟨i.val, h⟩).2.1
        (Wu04Bypass.coupled_kappa_cell ⟨i.val, h⟩) k) (by norm_num)
  · exact elementaryNodeCell_nonneg (first_geometry ⟨i.val - 4, by omega⟩).2.2.1
      (Wu04Bypass.first_cell ⟨i.val - 4, by omega⟩) k

theorem paidMatrix_nonneg (i k : Fin 9) : 0 ≤ paidMatrix i k :=
  (elementaryMatrix_nonneg i k).trans (elementaryMatrix_le_paidMatrix i k)

/-- This increment is an approximation improvement, not another feedback term. -/
def eGainMatrix (i k : Fin 9) : ℝ :=
  paidMatrix i k - Wu04Bypass.elementaryMatrix i k

theorem eGainMatrix_nonneg (i k : Fin 9) : 0 ≤ eGainMatrix i k :=
  sub_nonneg.mpr (elementaryMatrix_le_paidMatrix i k)

theorem elementary_add_gain (i k : Fin 9) :
    Wu04Bypass.elementaryMatrix i k + eGainMatrix i k = paidMatrix i k := by
  unfold eGainMatrix
  ring

theorem elementary_add_gain_le (i k : Fin 9) :
    Wu04Bypass.elementaryMatrix i k + eGainMatrix i k ≤ feedbackMatrix i k := by
  rw [elementary_add_gain]
  exact paidMatrix_le i k

theorem apply_comparison {z : Fin 9 → ℝ} (hz : ∀ k, 0 ≤ z k) (i : Fin 9) :
    (∑ k : Fin 9, Wu04Bypass.elementaryMatrix i k * z k) ≤
      (∑ k : Fin 9, paidMatrix i k * z k) ∧
    (∑ k : Fin 9, paidMatrix i k * z k) ≤ feedback z i := by
  exact ⟨Finset.sum_le_sum (fun k _ =>
    mul_le_mul_of_nonneg_right (elementaryMatrix_le_paidMatrix i k) (hz k)),
    paidMatrix_apply_le_feedback hz i⟩

theorem apply_gain_eq (z : Fin 9 → ℝ) (i : Fin 9) :
    (∑ k : Fin 9, Wu04Bypass.elementaryMatrix i k * z k) +
      (∑ k : Fin 9, eGainMatrix i k * z k) =
      (∑ k : Fin 9, paidMatrix i k * z k) := by
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro k _
  rw [← add_mul, elementary_add_gain]

end WuTarget.W08
