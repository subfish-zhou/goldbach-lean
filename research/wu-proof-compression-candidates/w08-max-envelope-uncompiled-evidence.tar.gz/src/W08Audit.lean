import W08FrozenConsumer
import W08CellCertificate

namespace WuTarget.W08

#check @paidCells_le_kernel
#print axioms paidCells_le_kernel
#check @paidCells_le_eProfile
#print axioms paidCells_le_eProfile
#check @paidCells_basis
#print axioms paidCells_basis
#check @paidCells_le_first
#print axioms paidCells_le_first
#check @paidCells_le_coupled
#print axioms paidCells_le_coupled
#check @paidMatrix
#print axioms paidMatrix
#check @paidMatrix_le
#print axioms paidMatrix_le
#check @paidMatrix_apply_eq
#print axioms paidMatrix_apply_eq
#check @paidMatrix_apply_le_feedback
#print axioms paidMatrix_apply_le_feedback
#check @paidMatrix_apply_le_actual
#print axioms paidMatrix_apply_le_actual
#check @terminal_first_cell_strict
#print axioms terminal_first_cell_strict

#check @entry00
#print axioms entry00
#check @entry10
#print axioms entry10
#check @entry20
#print axioms entry20
#check @entry30
#print axioms entry30
#check @entry40
#print axioms entry40
#check @entry50
#print axioms entry50
#check @entry60
#print axioms entry60
#check @entry70
#print axioms entry70
#check @entry80
#print axioms entry80

#check @elementaryMatrix_lt_paidMatrix_col0
#print axioms elementaryMatrix_lt_paidMatrix_col0
#check @elementaryMatrix_le_paidMatrix
#print axioms elementaryMatrix_le_paidMatrix
#check @elementaryCell_nonneg
#print axioms elementaryCell_nonneg
#check @elementaryNodeCell_nonneg
#print axioms elementaryNodeCell_nonneg
#check @elementaryMatrix_nonneg
#print axioms elementaryMatrix_nonneg
#check @paidMatrix_nonneg
#print axioms paidMatrix_nonneg
#check @paidMatrix_nonneg
#print axioms paidMatrix_nonneg
#check @eGainMatrix
#print axioms eGainMatrix
#check @eGainMatrix_nonneg
#print axioms eGainMatrix_nonneg
#check @elementary_add_gain
#print axioms elementary_add_gain
#check @elementary_add_gain_le
#print axioms elementary_add_gain_le
#check @apply_comparison
#print axioms apply_comparison
#check @apply_strict
#print axioms apply_strict
#check @apply_gain_eq
#print axioms apply_gain_eq
#check @v8_apply_strict
#print axioms v8_apply_strict
#check @v8_apply_le_feedback
#print axioms v8_apply_le_feedback
#check @v8_actual_consumer
#print axioms v8_actual_consumer

#print paidMatrix
#print eGainMatrix

end WuTarget.W08
