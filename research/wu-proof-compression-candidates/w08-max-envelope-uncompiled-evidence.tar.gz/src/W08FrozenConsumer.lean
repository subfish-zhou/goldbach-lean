import W08Envelope
import W08EntriesRest
import Wu04BypassActual

namespace WuTarget.W08
open ActualNineFeedback NodeExtension
open scoped BigOperators

/-- A strict witness in column zero suffices for the actual positive vector. -/
theorem elementaryMatrix_lt_paidMatrix_col0 (i : Fin 9) :
    Wu04Bypass.elementaryMatrix i 0 < paidMatrix i 0 := by
  fin_cases i
  · exact entry00
  · exact entry10
  · exact entry20
  · exact entry30
  · exact entry40
  · exact entry50
  · exact entry60
  · exact entry70
  · exact entry80

theorem apply_strict {z : Fin 9 → ℝ} (hz : ∀ k, 0 ≤ z k)
    (hpos : 0 < z 0) (i : Fin 9) :
    (∑ k : Fin 9, Wu04Bypass.elementaryMatrix i k * z k) <
      (∑ k : Fin 9, paidMatrix i k * z k) := by
  apply Finset.sum_lt_sum
  · intro k _
    exact mul_le_mul_of_nonneg_right (elementaryMatrix_le_paidMatrix i k) (hz k)
  · exact ⟨0, Finset.mem_univ 0,
      mul_lt_mul_of_pos_right (elementaryMatrix_lt_paidMatrix_col0 i) hpos⟩

theorem v8_apply_strict (i : Fin 9) :
    (∑ k : Fin 9, Wu04Bypass.elementaryMatrix i k * Wu04Bypass.v8 k) <
      (∑ k : Fin 9, paidMatrix i k * Wu04Bypass.v8 k) :=
  apply_strict Wu04Bypass.v8_nonneg (Wu04Bypass.new_vector_positive 0) i

theorem v8_apply_le_feedback (i : Fin 9) :
    (∑ k : Fin 9, paidMatrix i k * Wu04Bypass.v8 k) ≤ feedback Wu04Bypass.v8 i :=
  paidMatrix_apply_le_feedback Wu04Bypass.v8_nonneg i

theorem v8_actual_consumer :
    ∃ d : ℝ, 0 < d ∧ d ≤ 1 / 10 ∧
      ∀ δ : ℝ, 0 < δ → δ ≤ d → ∀ i : Fin 9,
        base i - deltaLoss δ * loss i +
          (∑ k : Fin 9, paidMatrix i k * Wu04Bypass.v8 k) ≤ actualNine δ i := by
  obtain ⟨d, hd, hcap, hv⟩ := Wu04Bypass.new_nine_actual
  refine ⟨d, hd, hcap, ?_⟩
  intro δ hδ hr i
  exact paidMatrix_apply_le_actual hδ (hr.trans hcap) Wu04Bypass.v8_nonneg
    (hv δ hδ hr) i

end WuTarget.W08
