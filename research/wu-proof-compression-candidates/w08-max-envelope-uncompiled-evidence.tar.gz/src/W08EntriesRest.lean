import W08Entries0

namespace WuTarget.W08
open Wu2008DoubleSieve SharpLogRecurrence JointLogTotalComparison
open ActualNineFeedback NodeExtension FirstFeedbackIntegrals FirstErrorFullPayment
open RemainingHf F1FullRecoveryPayment Wu04FactorEnvelopes

attribute [local simp] Wu04Bypass.elementaryMatrix paidMatrix cellEnvelope Wu04Bypass.cell cellLeft
  upperNode upperLeft coupledRow SecondFunctionalPositive.parameters
  SecondFunctionalParameters.row2 SecondFunctionalParameters.row3
  SecondFunctionalParameters.row4 firstS paidCell cellScale beta signed
  splitLower splitUpper basicLower basicUpper ea eb ec ed qa qb qc qd qe
  residualPrimitive residualDenom leftFactor rightFactor lowerLog upperLog
  V lowerGapPayment upperGapPayment F1LowerResidual.payment F1LowerResidual.denom

theorem entry10 : Wu04Bypass.elementaryMatrix 1 0 < paidMatrix 1 0 := by norm_num

theorem entry20 : Wu04Bypass.elementaryMatrix 2 0 < paidMatrix 2 0 := by norm_num

theorem entry30 : Wu04Bypass.elementaryMatrix 3 0 < paidMatrix 3 0 := by norm_num

theorem entry40 : Wu04Bypass.elementaryMatrix 4 0 < paidMatrix 4 0 := by norm_num

theorem entry50 : Wu04Bypass.elementaryMatrix 5 0 < paidMatrix 5 0 := by norm_num

theorem entry60 : Wu04Bypass.elementaryMatrix 6 0 < paidMatrix 6 0 := by norm_num

theorem entry70 : Wu04Bypass.elementaryMatrix 7 0 < paidMatrix 7 0 := by norm_num

theorem entry80 : Wu04Bypass.elementaryMatrix 8 0 < paidMatrix 8 0 := by norm_num

end WuTarget.W08
