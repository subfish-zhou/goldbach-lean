import W08KernelMatrix

namespace WuTarget.W08
open Wu2008DoubleSieve SharpLogRecurrence JointLogTotalComparison
open ActualNineFeedback NodeExtension FirstFeedbackIntegrals FirstErrorFullPayment
open RemainingHf F1FullRecoveryPayment Wu04FactorEnvelopes

attribute [local simp] Wu04Bypass.elementaryMatrix paidMatrix cellEnvelope Wu04Bypass.cell cellLeft
  upperNode upperLeft coupledRow SecondFunctionalPositive.parameters
  SecondFunctionalParameters.row1 paidCell cellScale beta signed
  splitLower splitUpper basicLower basicUpper ea eb ec ed qa qb qc qd qe
  residualPrimitive residualDenom leftFactor rightFactor lowerLog upperLog
  V lowerGapPayment upperGapPayment F1LowerResidual.payment F1LowerResidual.denom

theorem entry00 : Wu04Bypass.elementaryMatrix 0 0 < paidMatrix 0 0 := by norm_num

end WuTarget.W08
