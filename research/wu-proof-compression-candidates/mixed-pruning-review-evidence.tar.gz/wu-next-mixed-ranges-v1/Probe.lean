-- UNCOMPILED census template. This never retires or accepts a proof.
import Lean
import Lean.Util.FoldConsts
import WR2ClassicalCertificate
import W01ContinuousRoot
import W03Root
import W13Root
import W14AcceptedThreshold
import W15AcceptedThreshold
import W17ParentFullTypes
import WE10MajorAcceptedTotal
import WRMapMMatrixProbe
import WRMapMMatrixRoot
import WRecoveredFirstComparison
import WSrcFifthAnalyticInstance
import WSrcFourBudgetVerified
import WSrcFourEnclosureCone
import WSrcFourEnclosureFullTypes
import WSrcGridAccepted
import WSrcSingleGridInstance
import WSrcSingleRoot
import WSrcSixthGainRoot
import WSrcSixthGridInstance
import Wu2008Research

open Lean
namespace DeadProofFamilyAudit

private def lastString : Name → String
  | .str _ s => s
  | _ => ""

private partial def familyOf (targets : Std.HashMap Name String) (n : Name) :
    Option (Name × String) :=
  match targets[n]? with
  | some owner => some (n, owner)
  | none => match n with
    | .anonymous => none
    | .str p _ | .num p _ => familyOf targets p

private def kind : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition"
  | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

private def rangeJson (r : DeclarationRange) : Json := Json.mkObj [
  ("startLine", toJson r.pos.line), ("startColumn", toJson r.pos.column),
  ("endLine", toJson r.endPos.line), ("endColumn", toJson r.endPos.column)]

set_option maxHeartbeats 40000000 in
run_cmd do
  let env ← Lean.getEnv
  unless !env.header.isModule do
    throwError "Census requires a non-module environment"
  let moduleText ← Lean.Elab.Command.liftIO <| IO.FS.readFile "/tmp/wu-next-dead-family-census-v1/modules.txt"
  let moduleList := (moduleText.splitOn "\n").filter (· != "")
  let localSet : Std.HashSet String := moduleList.foldl (fun s n => s.insert n) {}
  unless localSet.size == moduleList.length do
    throwError "Duplicate module input"
  let requestedText ← Lean.Elab.Command.liftIO <| IO.FS.readFile "/tmp/wu-next-mixed-family-census-v1/requested.tsv"
  let mut wanted : Std.HashMap String String := {}
  let mut expectedKinds : Std.HashMap String String := {}
  for line in (requestedText.splitOn "\n").filter (· != "") do
    match line.splitOn "\t" with
    | [base, owner, expectedKind] =>
      unless expectedKind == "theorem" || expectedKind == "definition" do
        throwError "Unexpected source declaration kind: {expectedKind}"
      if wanted.contains base || !localSet.contains owner then
        throwError "Duplicate basename or unknown owner: {base} / {owner}"
      wanted := wanted.insert base owner
      expectedKinds := expectedKinds.insert base expectedKind
    | _ => throwError "Malformed requested declaration row"
  let mut decls : Array (Name × ConstantInfo × String) := #[]
  let mut observed : Std.HashSet String := {}
  for idx in [:env.header.moduleNames.size] do
    let owner := env.header.moduleNames[idx]!.toString
    if localSet.contains owner then
      observed := observed.insert owner
      let imported := env.header.modules[idx]!
      unless imported.importAll && imported.hasData do
        throwError "Missing private-inclusive module data: {owner}"
      let data := env.header.moduleData[idx]!
      unless data.constNames.size == data.constants.size do
        throwError "Constant name/data length mismatch: {owner}"
      let mut seen : Std.HashSet Name := {}
      for cidx in [:data.constants.size] do
        let n := data.constNames[cidx]!
        let ci := data.constants[cidx]!
        if ci.name != n || seen.contains n then
          throwError "Mismatched or repeated declaration in {owner}: {n}"
        seen := seen.insert n
        decls := decls.push (n, ci, owner)
  unless observed == localSet do
    throwError "Incomplete research-module coverage"
  let mut resolved : Std.HashMap String (Array Name) := {}
  for (n, ci, owner) in decls do
    if let some expected := wanted[lastString n]? then
      if owner == expected then
        unless expectedKinds[lastString n]? == some (kind ci) do
          throwError "Source declaration resolves to an unexpected constant kind: {n}"
        resolved := resolved.insert (lastString n) ((resolved[lastString n]?.getD #[]).push n)
  let mut rows : Array Json := #[]
  let mut rangeTargets : Std.HashMap Name String := {}
  for (base, owner) in wanted do
    let names := resolved[base]?.getD #[]
    unless names.size == 1 do
      throwError "Nonunique range target: {base}"
    let n := names[0]!
    rangeTargets := rangeTargets.insert n owner
    let ranges ← findDeclarationRanges? n
    let doc ← Lean.Elab.Command.liftIO <| findSimpleDocString? env n (includeBuiltin := false)
    rows := rows.push <| Json.mkObj [
      ("basename", toJson base), ("module", toJson owner), ("name", toJson n.toString),
      ("range", ranges.map (fun r => rangeJson r.range) |>.getD Json.null),
      ("selectionRange", ranges.map (fun r => rangeJson r.selectionRange) |>.getD Json.null),
      ("docString", toJson doc)]
  let mut familyRows : Array Json := #[]
  for (n, ci, owner) in decls do
    if let some (root, expected) := familyOf rangeTargets n then
      if owner == expected then
        let ranges ← findDeclarationRanges? n
        familyRows := familyRows.push <| Json.mkObj [
          ("name", toJson n.toString), ("family", toJson root.toString),
          ("module", toJson owner), ("kind", toJson (kind ci)),
          ("range", ranges.map (fun r => rangeJson r.range) |>.getD Json.null),
          ("selectionRange", ranges.map (fun r => rangeJson r.selectionRange) |>.getD Json.null)]
  let payload := Json.mkObj [
    ("schema", toJson "wu-declaration-and-family-ranges-v1"),
    ("status", toJson "ELABORATED_RANGE_METADATA_NOT_SOURCE_OWNERSHIP_OR_DELETION_ACCEPTANCE"),
    ("modules", toJson observed.size), ("rootCount", toJson rows.size),
    ("roots", Json.arr rows), ("members", Json.arr familyRows)]
  Lean.Elab.Command.liftIO <| IO.FS.writeFile "/tmp/wu-next-mixed-ranges-v1/ranges.json" payload.compress
end DeadProofFamilyAudit
