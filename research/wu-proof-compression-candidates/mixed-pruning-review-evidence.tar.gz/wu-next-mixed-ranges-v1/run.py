import fcntl, hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path
here=Path('/home/azureuser/goldbach-lean/research/wu-proof-compression-candidates')
sys.path.insert(0,str(here))
from audit_completed_batch import audit, sha
from validate_completed_batch import review_pins
out=Path(__file__).resolve().parent
plan_path=out/'plan.json';plan=json.loads(plan_path.read_text())
validation_path=Path('/tmp/wu-shared-proof-batch-v1/validation-inputs-02/validation-plan.json')
validation=json.loads(validation_path.read_text());report_path=validation_path.parent/'report.json';report=json.loads(report_path.read_text())
assert report['status']=='FULL_CONTEXT_EXPORTS_LITERALS_RETIREMENT_21_KERNELS_FRESH_UNION_PRODUCERS_PASS_NOT_INSTALLED' and len(report['steps'])==34
assert Path(plan['run'])==Path(validation['run'])
bindings={**plan['bindings'],**report['bindings'],str(plan_path):sha(plan_path),str(report_path):sha(report_path),str(Path(__file__)):sha(Path(__file__))}
census_dir=Path('/tmp/wu-next-mixed-family-census-v1')
census_result=json.loads((census_dir/'execution-result.json').read_text())
assert census_result['status']=='ACTUAL_MIXED_KIND_FAMILY_CENSUS_PASS_NOT_SOURCE_RETIREMENT_OR_ACCEPTANCE' and census_result['exit_code']==0
assert census_result['context_digest']==report['context_digest']
assert sha(census_dir/'census.json')==census_result['payload_sha256'] and sha(census_dir/'family-selection.json')==census_result['selection_sha256']
for path in [census_dir/'execution-result.json',census_dir/'census.json',census_dir/'family-selection.json']:bindings[str(path)]=sha(path)

def save(path,data):
 t=path.with_name(path.name+'.tmp');t.write_text(json.dumps(data,indent=2)+'\n');t.replace(path)
def check():
 for name,expected in bindings.items():assert sha(Path(name))==expected,name
state={'status':'STARTING_RANGE_QUERY_NOT_RETIREMENT_ACCEPTANCE','pid':os.getpid(),'start_ticks':Path(f'/proc/{os.getpid()}/stat').read_text().split()[21],'started_unix':time.time()}
with Path('/tmp/wu-lean-exclusive.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);check()
 run,baseline=Path(plan['run']),Path(validation['baseline'])
 before=audit(run,baseline);assert before['context_digest']==report['context_digest'];pins=review_pins(validation)
 save(out/'context-before.json',before);save(out/'pin-review.json',pins)
 assert not (out/'ranges.json').exists() and not (out/'execution-result.json').exists()
 (out/'tmp').mkdir(exist_ok=True)
 env=os.environ.copy()
 for k in ['LEAN_PATH','LEAN_SYSROOT','LEAN_SRC_PATH']:env.pop(k,None)
 env.update(LEAN_PATH=':'.join([str(run/'build/lib'),*validation['package_paths']]),LEAN_SYSROOT=str(Path(validation['lean']).parent.parent),TMPDIR=str(out/'tmp'))
 cmd=[validation['lean'],'-j1','-DwarningAsError=true','-DautoImplicit=false','-DmaxRecDepth=16384','-R',str(out),'-o',str(out/'Probe.olean'),str(out/'Probe.lean')]
 measured=['/usr/bin/time','-v','-o',str(out/'resources.txt'),*cmd]
 save(out/'invocation.json',{'command':cmd,'execution_command':measured,'environment':{k:env[k] for k in ['LEAN_PATH','LEAN_SYSROOT','TMPDIR']},'bindings':bindings})
 child=None
 def stop(signum,frame):raise InterruptedError(f'mixed census interrupted by {signum}')
 for s in [signal.SIGTERM,signal.SIGINT]:signal.signal(s,stop)
 start=time.monotonic()
 try:
  with (out/'compile.log').open('x') as log:
   child=subprocess.Popen(measured,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   state.update(status='RANGE_QUERY_RUNNING_NOT_RETIREMENT_ACCEPTANCE',child_pid=child.pid);save(out/'process.json',state)
   print('RANGE_QUERY_STARTED',child.pid,flush=True)
   rc=child.wait(timeout=1800)
  result={'status':'RANGE_QUERY_QUERY_RETURNED_NOT_ACCEPTANCE','exit_code':rc,'seconds':time.monotonic()-start,'log_sha256':sha(out/'compile.log'),'invocation_sha256':sha(out/'invocation.json'),'resources_sha256':sha(out/'resources.txt')}
  save(out/'execution-result.json',result);assert rc==0,rc
  payload=json.loads((out/'ranges.json').read_text())
  assert payload['schema']=='wu-declaration-and-family-ranges-v1' and payload['modules']==4151 and payload['rootCount']==3807
  census_dir=Path('/tmp/wu-next-mixed-family-census-v1')
  census=json.loads((census_dir/'census.json').read_text());selected=json.loads((census_dir/'family-selection.json').read_text())
  rows=payload['roots'];assert len(rows)==3807
  assert {(r['name'],r['basename'],r['module']) for r in rows}=={(r['name'],r['basename'],r['module']) for r in census['candidates']}
  assert {(r['name'],r['family'],r['module'],r['kind']) for r in payload['members']}=={(r['name'],r['family'],r['module'],r['kind']) for r in census['members']}
  by_name={r['name']:r for r in rows};wanted={r['name'] for r in selected['selected']}
  missing=[n for n in wanted if by_name[n]['range'] is None or by_name[n]['selectionRange'] is None];assert not missing,missing
  check();after=audit(run,baseline);assert after==before and review_pins(validation)==pins;save(out/'context-after.json',after)
  result.update(status='ACTUAL_COMPILER_ROOT_AND_FAMILY_RANGES_PASS_NOT_SOURCE_RETIREMENT_OR_ACCEPTANCE',context_digest=before['context_digest'],payload_sha256=sha(out/'ranges.json'),root_declarations=len(rows),roots_with_ranges=sum(r['range'] is not None for r in rows),selected_roots_with_ranges=len(wanted),family_members=len(payload['members']),family_members_with_ranges=sum(r['range'] is not None for r in payload['members']))
  save(out/'execution-result.json',result);state.update(status=result['status'],exit_code=0,finished_unix=time.time());save(out/'process.json',state);print(json.dumps(result),flush=True)
 except BaseException as error:
  if child is not None and child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  state.update(status='RANGE_QUERY_STOPPED_NOT_ACCEPTED',error_type=type(error).__name__,error=str(error),finished_unix=time.time());save(out/'process.json',state);raise
