import fcntl,json,os,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,'/home/azureuser/goldbach-lean/research/wu-proof-compression-candidates')
from audit_completed_batch import audit,sha
from validate_completed_batch import review_pins
out=Path(__file__).resolve().parent
plan=json.loads((out/'probe-plan.json').read_text())
vp=Path('/tmp/wu-shared-proof-batch-v1/validation-inputs-02/validation-plan.json')
v=json.loads(vp.read_text());report=json.loads((vp.parent/'report.json').read_text())
assert report['status']=='FULL_CONTEXT_EXPORTS_LITERALS_RETIREMENT_21_KERNELS_FRESH_UNION_PRODUCERS_PASS_NOT_INSTALLED'
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
def check():
 for name,wanted in plan['bindings'].items():assert sha(Path(name))==wanted,name
with Path('/tmp/wu-lean-exclusive.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 check();before=audit(Path(v['run']),Path(v['baseline']));assert before['context_digest']==report['context_digest'];pins=review_pins(v)
 save('probe-context-before.json',before);save('probe-pins.json',pins)
 state=dict(status='SINGLE_MODULE_PROBE_RUNNING',pid=os.getpid(),start_ticks=Path(f'/proc/{os.getpid()}/stat').read_text().split()[21],steps=[])
 save('probe-process.json',state)
 for step in plan['steps']:
  env=os.environ.copy()
  for key in ['LEAN_PATH','LEAN_SYSROOT','LEAN_SRC_PATH']:env.pop(key,None)
  env.update(step['environment'])
  command=step['command'];log=out/(step['label']+'.log')
  if '-o' in command:Path(command[command.index('-o')+1]).parent.mkdir(parents=True,exist_ok=True)
  start=time.monotonic()
  with log.open('x') as handle:
   child=subprocess.Popen(command,env=env,cwd=out,stdout=handle,stderr=subprocess.STDOUT)
   state['child_pid']=child.pid;state['current_step']=step['label'];save('probe-process.json',state)
   rc=child.wait(timeout=1800)
  row=dict(label=step['label'],command=command,environment=step['environment'],exit_code=rc,seconds=time.monotonic()-start,log_sha256=sha(log))
  state['steps'].append(row);save('probe-process.json',state);print(step['label'],rc,flush=True)
  assert rc==0,log.read_text()
 a,b=[json.loads(Path(p).read_text()) for p in plan['compare_exact_raw_json']]
 assert a==b
 check();after=audit(Path(v['run']),Path(v['baseline']));assert before==after and review_pins(v)==pins
 save('probe-context-after.json',after)
 state.update(status='SINGLE_CHANGED_MODULE_COMPILE_AND_EXACT_TYPE_AXIOMS_PASS_NO_DOWNSTREAM_ACCEPTANCE',exit_code=0,before_type_sha256=sha(Path(plan['compare_exact_raw_json'][0])),after_type_sha256=sha(Path(plan['compare_exact_raw_json'][1])),context_digest=before['context_digest'],plan_sha256=sha(out/'probe-plan.json'),runner_sha256=sha(Path(__file__)))
 save('probe-result.json',state);save('probe-process.json',state)
 print(state['status'],flush=True)
