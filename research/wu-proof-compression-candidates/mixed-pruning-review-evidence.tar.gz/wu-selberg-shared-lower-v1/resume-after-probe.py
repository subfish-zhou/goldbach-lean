import fcntl,json,os,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,'/home/azureuser/goldbach-lean/research/wu-proof-compression-candidates')
from audit_completed_batch import sha,audit
from validate_completed_batch import review_pins
out=Path(__file__).resolve().parent
plan=json.loads((out/'probe-plan.json').read_text());old=json.loads((out/'probe-process.json').read_text())
assert [s['exit_code'] for s in old['steps']]==[0,0,1]
v=json.loads(Path('/tmp/wu-shared-proof-batch-v1/validation-inputs-02/validation-plan.json').read_text())
with Path('/tmp/wu-lean-exclusive.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for p,h in plan['bindings'].items():assert sha(Path(p))==h,p
 before=audit(Path(v['run']),Path(v['baseline']));assert before==json.loads((out/'probe-context-before.json').read_text())
 assert review_pins(v)==json.loads((out/'probe-pins.json').read_text())
 for src in (Path(v['run'])/'build/lib').rglob('*'):
  if src.is_file():
   dest=out/'lib'/src.relative_to(Path(v['run'])/'build/lib')
   if not str(src).endswith('MathlibNt/SieveTheory/Selberg/SelbergUpperBound.olean'):assert sha(dest)==sha(src),src
 step=plan['steps'][-1];env=os.environ.copy();env.update(step['environment']);start=time.monotonic()
 with (out/'after-type-and-axioms-resume.log').open('x') as log:r=subprocess.run(step['command'],env=env,cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
 result=dict(status='AFTER_PROBE_RETURNED_NOT_ACCEPTED',exit_code=r.returncode,seconds=time.monotonic()-start,command=step['command'],environment=step['environment'],log_sha256=sha(out/'after-type-and-axioms-resume.log'),prior_steps=old['steps'],library_repair_sha256=sha(out/'probe-library-prefix-repair.json'))
 (out/'probe-resume-result.json').write_text(json.dumps(result,indent=2)+'\n');assert r.returncode==0,(out/'after-type-and-axioms-resume.log').read_text()
 a,b=[json.loads(Path(p).read_text()) for p in plan['compare_exact_raw_json']];assert a==b
 after=audit(Path(v['run']),Path(v['baseline']));assert before==after
 result.update(status='SINGLE_CHANGED_MODULE_COMPILE_AND_EXACT_TYPE_AXIOMS_PASS_NO_DOWNSTREAM_ACCEPTANCE',context_digest=before['context_digest'],before_type_sha256=sha(Path(plan['compare_exact_raw_json'][0])),after_type_sha256=sha(Path(plan['compare_exact_raw_json'][1])),runner_sha256=sha(Path(__file__)))
 (out/'probe-resume-result.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],flush=True)
