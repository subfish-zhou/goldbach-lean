import fcntl,json,os,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,'/home/azureuser/goldbach-lean/research/wu-proof-compression-candidates')
from audit_completed_batch import audit,sha
from validate_completed_batch import review_pins
out=Path(__file__).resolve().parent;base=Path('/tmp/wu-shared-proof-batch-v1/run-20261028-01');plan=json.loads((base.parent/'validation-inputs-02/validation-plan.json').read_text())
with Path('/tmp/wu-lean-exclusive.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);before=audit(base,Path(plan['baseline']));pins=review_pins(plan);env=os.environ.copy();env.update(LEAN_PATH=':'.join([str(base/'build/lib'),*plan['package_paths']]),LEAN_SYSROOT=str(Path(plan['lean']).parent.parent));cmd=[plan['lean'],'-j1','-DwarningAsError=true','-DautoImplicit=false','-DmaxRecDepth=16384','-R',str(out),'-o',str(out/'Probe.olean'),str(out/'Probe.lean')];start=time.monotonic()
 inputs={str(p):sha(p)for p in [Path(__file__),out/'Probe.lean',out/'requested.tsv',out/'modules.txt']}
 with (out/'compile.log').open('x') as handle:r=subprocess.run(cmd,cwd=out,env=env,stdout=handle,stderr=subprocess.STDOUT,timeout=1800)
 result=dict(status='EXTRA_RETIREMENT_CENSUS_RETURNED_NOT_ACCEPTED',exit_code=r.returncode,seconds=time.monotonic()-start,command=cmd,environment={k:env[k]for k in ['LEAN_PATH','LEAN_SYSROOT']},input_bindings=inputs,log_sha256=sha(out/'compile.log'));(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');assert r.returncode==0,(out/'compile.log').read_text()
 data=json.loads((out/'census.json').read_text());assert data['candidateCount']==84 and data['modules']==4151;assert audit(base,Path(plan['baseline']))==before and review_pins(plan)==pins
 result.update(status='ACTUAL_EXTRA_W08_RETIREMENT_FAMILIES_PASS_NOT_SOURCE_ACCEPTANCE',payload_sha256=sha(out/'census.json'),context_digest=before['context_digest'],members=len(data['members']),ownership_issues=len(data['ownershipIssues']));(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
