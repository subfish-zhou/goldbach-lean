from pathlib import Path
import hashlib,importlib.util,json,re,time
r=Path(__file__).resolve().parent;repo=Path('/home/azureuser/goldbach-lean');spec=importlib.util.spec_from_file_location('published_counter',repo/'scripts/check.py');counter=importlib.util.module_from_spec(spec);spec.loader.exec_module(counter)
manifest_path=r/'source-manifest.json';raw=manifest_path.read_bytes();manifest={x['module']:x for x in json.loads(raw)};names=set(manifest);mismatches=[];source_graph={}
pattern=re.compile(r'^\s*(?:(?:public|meta)\s+)*import\s+(.+)',re.M)
for name,row in manifest.items():
 path=r/'src'/Path(*name.split('.')).with_suffix('.lean');data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==row['source_sha256'],name
 imports=[word for match in pattern.finditer(counter.code_only(data.decode())) for word in match[1].split()];local=[x for x in imports if x in names];recorded=[x for x in row['imports'] if x in names];source_graph[name]=local
 if local!=recorded:mismatches.append(dict(module=name,actual_source_local_imports=local,recorded_manifest_local_imports=recorded))
closure=set();todo=['WR2ClassicalCertificate']
while todo:
 name=todo.pop()
 if name not in closure:closure.add(name);todo.extend(source_graph[name])
result=dict(status='SOURCE_IMPORT_GRAPH_REVIEW_NOT_PROOF_ACCEPTANCE',manifest_sha256=hashlib.sha256(raw).hexdigest(),modules=len(manifest),local_import_graph_mismatches=mismatches,actual_source_final_closure_modules=len(closure),all_source_hashes_match=True,observed_unix=time.time())
(r/'source-import-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert not mismatches
