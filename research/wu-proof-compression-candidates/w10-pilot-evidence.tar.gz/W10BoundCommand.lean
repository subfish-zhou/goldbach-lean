import W10Interval

/-- Interval proof declarations keep theorem opacity and infer their exact statement. -/
macro "box_bound " n:ident " := " proof:term : command =>
  `(theorem $n : type_of% $proof := $proof)
