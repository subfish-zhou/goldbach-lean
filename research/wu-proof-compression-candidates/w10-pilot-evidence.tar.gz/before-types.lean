import Lean
import W10Log12
open Lean
namespace PublicInterfaceAudit

private def node (tag : String) (args : Array Json := #[]) : Json :=
  .arr (#[toJson tag] ++ args)

private def nameTree : Name → Json
  | .anonymous => node "anonymous"
  | .str p s => node "str" #[nameTree p, toJson s]
  | .num p n => node "num" #[nameTree p, toJson n]

private def paramIndex (n : Name) : List Name → Option Nat
  | [] => none
  | p :: ps => if n == p then some 0 else (paramIndex n ps).map (· + 1)

private partial def levelTree (ps : List Name) : Level → Except String Json
  | .zero => return node "zero"
  | .succ u => return node "succ" #[← levelTree ps u]
  | .max u v => return node "max" #[← levelTree ps u, ← levelTree ps v]
  | .imax u v => return node "imax" #[← levelTree ps u, ← levelTree ps v]
  | .param p => match paramIndex p ps with
    | some i => return node "param" #[toJson i]
    | none => throw s!"Undeclared universe parameter: {p}"
  | .mvar _ => throw "Universe metavariable in public declaration"

private def binderTree : BinderInfo → Json
  | .default => toJson "default"
  | .implicit => toJson "implicit"
  | .strictImplicit => toJson "strictImplicit"
  | .instImplicit => toJson "instImplicit"

private partial def exprTree (ps : List Name) : Expr → Except String Json
  | .bvar i => return node "bvar" #[toJson i]
  | .fvar _ => throw "Free variable in public declaration"
  | .mvar _ => throw "Expression metavariable in public declaration"
  | .sort u => return node "sort" #[← levelTree ps u]
  | .const n us => do
    let levels ← us.mapM (levelTree ps)
    return node "const" #[nameTree n, .arr levels.toArray]
  | .app f x => return node "app" #[← exprTree ps f, ← exprTree ps x]
  | .lam _ t b bi => return node "lam" #[binderTree bi, ← exprTree ps t, ← exprTree ps b]
  | .forallE _ t b bi => return node "forall" #[binderTree bi, ← exprTree ps t, ← exprTree ps b]
  | .letE _ t v b nondep => return node "let" #[toJson nondep, ← exprTree ps t, ← exprTree ps v, ← exprTree ps b]
  | .lit (.natVal n) => return node "nat" #[toJson n]
  | .lit (.strVal s) => return node "string" #[toJson s]
  | .mdata _ e => exprTree ps e
  | .proj n i e => return node "proj" #[nameTree n, toJson i, ← exprTree ps e]

private def kind : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition"
  | .thmInfo _ => "theorem" | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient" | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

private def declaration (ci : ConstantInfo) (includeDefinitions : Bool) : Except String Json := do
  let ty ← exprTree ci.levelParams ci.type
  let value ←
    if includeDefinitions then
      match ci with
      | .defnInfo d => exprTree ci.levelParams d.value
      | _ => throw s!"Requested definition value for non-definition: {ci.name}"
    else pure Json.null
  return Json.mkObj [
    ("name", toJson ci.name.toString), ("kind", toJson (kind ci)),
    ("levelParamCount", toJson ci.levelParams.length),
    ("type", ty), ("definitionValue", value)]

run_cmd do
  let env ← Lean.getEnv
  let requested : List Name := [`WuTarget.W10.W10Log12_b3, `WuTarget.W10.W10Log12_b2, `WuTarget.W10.W10Log12_b6, `WuTarget.W10.W10Log12_b5, `WuTarget.W10.W10Log12_b7, `WuTarget.W10.W10Log12_b4, `WuTarget.W10.W10Log12_b8, `WuTarget.W10.W10Log12_b1, `WuTarget.W10.W10Log12_b15, `WuTarget.W10.W10Log12_b20, `WuTarget.W10.W10Log12_b19, `WuTarget.W10.W10Log12_b21, `WuTarget.W10.W10Log12_b18, `WuTarget.W10.W10Log12_b17, `WuTarget.W10.W10Log12_b22, `WuTarget.W10.W10Log12_b23, `WuTarget.W10.W10Log12_b16, `WuTarget.W10.W10Log12_b14, `WuTarget.W10.W10Log12_b26, `WuTarget.W10.W10Log12_b25, `WuTarget.W10.W10Log12_b27, `WuTarget.W10.W10Log12_b28, `WuTarget.W10.W10Log12_b24, `WuTarget.W10.W10Log12_b13, `WuTarget.W10.W10Log12_b32, `WuTarget.W10.W10Log12_b31, `WuTarget.W10.W10Log12_b35, `WuTarget.W10.W10Log12_b37, `WuTarget.W10.W10Log12_b36, `WuTarget.W10.W10Log12_b34, `WuTarget.W10.W10Log12_b33, `WuTarget.W10.W10Log12_b38, `WuTarget.W10.W10Log12_b30, `WuTarget.W10.W10Log12_b45, `WuTarget.W10.W10Log12_b44, `WuTarget.W10.W10Log12_b43, `WuTarget.W10.W10Log12_b42, `WuTarget.W10.W10Log12_b41, `WuTarget.W10.W10Log12_b46, `WuTarget.W10.W10Log12_b47, `WuTarget.W10.W10Log12_b40, `WuTarget.W10.W10Log12_b39, `WuTarget.W10.W10Log12_b29, `WuTarget.W10.W10Log12_b12, `WuTarget.W10.W10Log12_b50, `WuTarget.W10.W10Log12_b53, `WuTarget.W10.W10Log12_b52, `WuTarget.W10.W10Log12_b54, `WuTarget.W10.W10Log12_b51, `WuTarget.W10.W10Log12_b49, `WuTarget.W10.W10Log12_b56, `WuTarget.W10.W10Log12_b59, `WuTarget.W10.W10Log12_b58, `WuTarget.W10.W10Log12_b57, `WuTarget.W10.W10Log12_b55, `WuTarget.W10.W10Log12_b60, `WuTarget.W10.W10Log12_b48, `WuTarget.W10.W10Log12_b11, `WuTarget.W10.W10Log12_b68, `WuTarget.W10.W10Log12_b69, `WuTarget.W10.W10Log12_b67, `WuTarget.W10.W10Log12_b66, `WuTarget.W10.W10Log12_b70, `WuTarget.W10.W10Log12_b71, `WuTarget.W10.W10Log12_b65, `WuTarget.W10.W10Log12_b64, `WuTarget.W10.W10Log12_b74, `WuTarget.W10.W10Log12_b73, `WuTarget.W10.W10Log12_b72, `WuTarget.W10.W10Log12_b63, `WuTarget.W10.W10Log12_b77, `WuTarget.W10.W10Log12_b80, `WuTarget.W10.W10Log12_b81, `WuTarget.W10.W10Log12_b79, `WuTarget.W10.W10Log12_b78, `WuTarget.W10.W10Log12_b82, `WuTarget.W10.W10Log12_b76, `WuTarget.W10.W10Log12_b88, `WuTarget.W10.W10Log12_b87, `WuTarget.W10.W10Log12_b86, `WuTarget.W10.W10Log12_b85, `WuTarget.W10.W10Log12_b89, `WuTarget.W10.W10Log12_b90, `WuTarget.W10.W10Log12_b84, `WuTarget.W10.W10Log12_b83, `WuTarget.W10.W10Log12_b75, `WuTarget.W10.W10Log12_b62, `WuTarget.W10.W10Log12_b93, `WuTarget.W10.W10Log12_b95, `WuTarget.W10.W10Log12_b94, `WuTarget.W10.W10Log12_b92, `WuTarget.W10.W10Log12_b99, `WuTarget.W10.W10Log12_b98, `WuTarget.W10.W10Log12_b97, `WuTarget.W10.W10Log12_b96, `WuTarget.W10.W10Log12_b100, `WuTarget.W10.W10Log12_b91, `WuTarget.W10.W10Log12_b61, `WuTarget.W10.W10Log12_b10, `WuTarget.W10.W10Log12_b104, `WuTarget.W10.W10Log12_b103, `WuTarget.W10.W10Log12_b106, `WuTarget.W10.W10Log12_b109, `WuTarget.W10.W10Log12_b108, `WuTarget.W10.W10Log12_b107, `WuTarget.W10.W10Log12_b105, `WuTarget.W10.W10Log12_b110, `WuTarget.W10.W10Log12_b102, `WuTarget.W10.W10Log12_b113, `WuTarget.W10.W10Log12_b112, `WuTarget.W10.W10Log12_b117, `WuTarget.W10.W10Log12_b116, `WuTarget.W10.W10Log12_b115, `WuTarget.W10.W10Log12_b114, `WuTarget.W10.W10Log12_b118, `WuTarget.W10.W10Log12_b111, `WuTarget.W10.W10Log12_b101, `WuTarget.W10.W10Log12_b9, `WuTarget.W10.W10Log12_b124, `WuTarget.W10.W10Log12_b125, `WuTarget.W10.W10Log12_b123, `WuTarget.W10.W10Log12_b126, `WuTarget.W10.W10Log12_b122, `WuTarget.W10.W10Log12_b130, `WuTarget.W10.W10Log12_b129, `WuTarget.W10.W10Log12_b128, `WuTarget.W10.W10Log12_b131, `WuTarget.W10.W10Log12_b127, `WuTarget.W10.W10Log12_b121, `WuTarget.W10.W10Log12_b135, `WuTarget.W10.W10Log12_b136, `WuTarget.W10.W10Log12_b134, `WuTarget.W10.W10Log12_b133, `WuTarget.W10.W10Log12_b139, `WuTarget.W10.W10Log12_b138, `WuTarget.W10.W10Log12_b140, `WuTarget.W10.W10Log12_b137, `WuTarget.W10.W10Log12_b132, `WuTarget.W10.W10Log12_b120, `WuTarget.W10.W10Log12_b145, `WuTarget.W10.W10Log12_b147, `WuTarget.W10.W10Log12_b146, `WuTarget.W10.W10Log12_b144, `WuTarget.W10.W10Log12_b150, `WuTarget.W10.W10Log12_b151, `WuTarget.W10.W10Log12_b149, `WuTarget.W10.W10Log12_b152, `WuTarget.W10.W10Log12_b148, `WuTarget.W10.W10Log12_b153, `WuTarget.W10.W10Log12_b143, `WuTarget.W10.W10Log12_b156, `WuTarget.W10.W10Log12_b155, `WuTarget.W10.W10Log12_b157, `WuTarget.W10.W10Log12_b154, `WuTarget.W10.W10Log12_b142, `WuTarget.W10.W10Log12_b161, `WuTarget.W10.W10Log12_b163, `WuTarget.W10.W10Log12_b162, `WuTarget.W10.W10Log12_b160, `WuTarget.W10.W10Log12_b166, `WuTarget.W10.W10Log12_b165, `WuTarget.W10.W10Log12_b167, `WuTarget.W10.W10Log12_b164, `WuTarget.W10.W10Log12_b168, `WuTarget.W10.W10Log12_b159, `WuTarget.W10.W10Log12_b171, `WuTarget.W10.W10Log12_b170, `WuTarget.W10.W10Log12_b172, `WuTarget.W10.W10Log12_b169, `WuTarget.W10.W10Log12_b158, `WuTarget.W10.W10Log12_b141, `WuTarget.W10.W10Log12_b119, `WuTarget.W10.log12_bounds]
  let mut entries : Array Json := #[]
  for n in requested do
    let some ci := env.find? n | throwError "missing declaration {n}"
    match declaration ci false with
    | .error e => throwError "{e}"
    | .ok j => entries := entries.push j
  Lean.Elab.Command.liftIO <| IO.FS.writeFile "/tmp/wu-w10-inference-v1/before-types.json" (Json.arr entries).compress
end PublicInterfaceAudit
